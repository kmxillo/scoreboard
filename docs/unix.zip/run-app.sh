#!/usr/bin/env bash
java -jar build/libs/scoreboard-console.jar
